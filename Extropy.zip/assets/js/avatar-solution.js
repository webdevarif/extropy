(function ($) {

	/*=============================================
		=    	OUR CUSTOM PLUGIN NAME 	         =
	=============================================*/
	$.fn.AvatarSolution = function () {}

}(jQuery));

